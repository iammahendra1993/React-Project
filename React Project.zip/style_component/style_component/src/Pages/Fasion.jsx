import React from 'react'

function Fasion() {
  return (
    <div>
      <div className="blue_bg">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="titlepage">
                <h2>Fashion</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* fashion section */}
      <div className="fashion">
        <img src="images/fashion.jpg" alt="#" />
      </div>
      {/* end fashion section */}
    </div>

  )
}

export default Fasion
